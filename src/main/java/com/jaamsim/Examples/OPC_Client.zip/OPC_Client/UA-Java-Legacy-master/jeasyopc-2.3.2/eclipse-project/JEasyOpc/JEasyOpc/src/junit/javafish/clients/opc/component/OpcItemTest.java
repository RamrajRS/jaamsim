package javafish.clients.opc.component;

import junit.framework.TestCase;

public class OpcItemTest extends TestCase {

  protected void setUp() throws Exception {
    super.setUp();
  }

  public void testIsActive() {
    fail("Not yet implemented");
  }

  public void testSetActive() {
    fail("Not yet implemented");
  }

  public void testIsQuality() {
    fail("Not yet implemented");
  }

  public void testSetQuality() {
    fail("Not yet implemented");
  }

  public void testGetValue() {
    fail("Not yet implemented");
  }

  public void testSetValue() {
    fail("Not yet implemented");
  }

  public void testGetTimeStamp() {
    fail("Not yet implemented");
  }

  public void testSetTimeStamp() {
    fail("Not yet implemented");
  }

  public void testGetAccessPath() {
    fail("Not yet implemented");
  }

  public void testGetClientHandle() {
    fail("Not yet implemented");
  }

  public void testGetDataType() {
    fail("Not yet implemented");
  }

  public void testGetItemName() {
    fail("Not yet implemented");
  }

  public void testClone() {
    fail("Not yet implemented");
  }

}
